# Smart Money — MVP

A beginner-friendly personal finance tracker built with Python, Streamlit and SQLite.

## Features

- Dashboard
- Income and expense tracking
- Automatic category suggestion from descriptions
- Indian payment methods including UPI
- Transaction history and search
- Monthly budgets
- Spending analysis
- Category charts
- Persistent SQLite database

## 1. Install Python

Install Python 3.11 or newer.

During Windows installation, enable:

`Add Python to PATH`

## 2. Open the project folder

Open Command Prompt / PowerShell in this folder.

## 3. Create a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

Mac/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 4. Install dependencies

```bash
pip install -r requirements.txt
```

## 5. Run the app

```bash
streamlit run app.py
```

Your browser should open automatically.

If it doesn't, Streamlit will show a local address such as:

`http://localhost:8501`

## Database

The first run automatically creates:

`smart_money.db`

Do not delete this file if you want to keep your transaction data.

## Important

This is an MVP/prototype. It does NOT connect directly to banks or UPI accounts and it does not provide regulated financial advice.

## Suggested V2

After testing the MVP with real users:

1. User authentication
2. Cloud database
3. CSV bank-statement import
4. Better automatic categorization
5. AI-powered "Ask My Money"
6. Recurring expenses
7. Notifications
8. Mobile-first UI
9. Secure financial-data architecture
10. Bank/financial-data integrations only after reviewing applicable Indian regulatory and consent requirements
